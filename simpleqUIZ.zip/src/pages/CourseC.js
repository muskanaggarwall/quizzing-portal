import React from "react";

function CourseC() {
  return <div>Course C</div>;
}

export default CourseC;
