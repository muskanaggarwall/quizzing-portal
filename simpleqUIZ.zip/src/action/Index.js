export function SignupCredential(a) {
  return {
    type: "CREDENTIALS",
    payload: a,
  };
}
