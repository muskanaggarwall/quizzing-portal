import { Link } from "react-router-dom";
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import "./SignUp.css";

function SignUp(props) {
  const selector = useSelector((state) => state.reducer);
  const dispatch = useDispatch();
  //setting states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  //setting errors
  let errorsObj = { name: "", email: "", password: "" };
  const [errors, setErrors] = useState(errorsObj);

  function onSignUp(e) {
    e.preventDefault();
    let error = false;
    const errorObj = { ...errorsObj };
    if (name === "") {
      errorObj.name = "Name is Required";
      error = true;
    }

    if (email === "") {
      errorObj.email = "Email is Required";
      error = true;
    }

    if (password === "") {
      errorObj.password = "Password is Required";
      error = true;
    }

    setErrors(errorObj);

    if (!error) {
      console.log("form submit");
    }
  }

  return (
    <div className="signup">
      {/* <h1 className="signup">{selector.email} Sign Up</h1> */}

      <form className="signup_form" onSubmit={onSignUp}>
        <div>
          <label>Name</label>
          <div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          {errors.name && <div>{errors.name}</div>}
        </div>

        <div>
          <label>Email</label>
          <div>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          {errors.email && <div>{errors.email}</div>}
        </div>
        <div>
          <label>Password</label>
          <div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {errors.password && <div>{errors.password}</div>}
        </div>

        <div className="my-3">
          <button type="submit" className="c">
            Sign Up
          </button>
        </div>
        <Link to={"/course"}>Redirect to Course</Link>
      </form>
    </div>
  );
}

export default SignUp;
